﻿using Microsoft.EntityFrameworkCore;
using VITItems.Repository.Interface;
using System;
using System.Collections.Generic;

using System.Linq;
using System.Text;
using VITItems.Repository.EFCore;
using Threading = System.Threading.Tasks;
using VITItems.Entity;

namespace VITItems.Repository.EFCore.RepositoryImplementation
{
   public class PublicClientListRepository : BaseRepository, IPublicClientListRepository
    {
        private readonly VITDBContext vitDBContext;

        public PublicClientListRepository(VITDBContext dBContext) : base(dBContext)
        {
            this.vitDBContext = dBContext;
        }

        public async Threading.Task<List<PublicClientListDetails>> GetPublicClientList()
        {
            return await vitDBContext.Set<PublicClientListDetails>().FromSql("EXECUTE spPublicClient_GetAll").AsNoTracking().ToListAsync();
        }


    }
}
