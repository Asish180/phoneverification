﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MachinePlatform.Repository.EFCore.RepositoryImplementation
{
   public class BaseRepository
    {
        protected readonly MachinePlatformDBContext machinePlatformDBContext;

        public BaseRepository(MachinePlatformDBContext machinePlatformDBContext)
        {
            this.machinePlatformDBContext = machinePlatformDBContext;
        }

    }
}
