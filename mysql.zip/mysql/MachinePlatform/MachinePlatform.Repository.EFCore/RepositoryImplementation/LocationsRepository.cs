﻿using Microsoft.EntityFrameworkCore;
using VITItems.Repository.Interface;
using System;
using System.Collections.Generic;

using System.Linq;
using System.Text;
using VITItems.Repository.EFCore;
using Threading = System.Threading.Tasks;
using VITItems.Entity;

namespace VITItems.Repository.EFCore.RepositoryImplementation
{
   public class LocationsRepository :BaseRepository, ILocationsRepository
    {
        private readonly VITDBContext VITDBContext;

        public LocationsRepository(VITDBContext dBContext) : base(dBContext)
        {
            this.VITDBContext = dBContext;
        }

        public  List<Locations> GetAllLocationsAsyncold()
        {
            List<Locations> locationList = new List<Locations>();
           // var locationList =  VITDBContext.Locations.OrderBy(item => item.LocationName).ToList();
               return locationList;
        }

        //public List<Locations> GetAllLocationsAsync()
        //{

        //    var locationList = VITDBContext.Locations.OrderBy(item => item.LocationName).ToList();
        //    return locationList;
        //}

        public int getInt()
        {
            return 5;
        }

        //public List<Locations> GetAllLocationsAsync()
        // {
        //     List<Locations> locationList = new List<Locations>();
        //     // var locationList =  VITDBContext.Locations.OrderBy(item => item.LocationName).ToList();
        //     return locationList;
        // }
        public async Threading.Task<List<RestrictionsDetails>> GetRestrictionsDetails()
        {
            return await VITDBContext.Set<RestrictionsDetails>().FromSql("EXECUTE spRestrictions_GetAllRestrictions").AsNoTracking().ToListAsync();
        }

        public async Threading.Task<List<LocationTree>> GetLocationTree()
        {
            return await VITDBContext.Set<LocationTree>().FromSql("EXECUTE spLocations_GetDetailsAPI").AsNoTracking().ToListAsync();
        }
        int ILocationsRepository.getInt()
        {
            throw new NotImplementedException();
        }

        public async Threading.Task<List<Locations>> GetAllLocationsAsync()
        {
            // List<Locations> locationList = new List<Locations>();
            try
            {
                var locationList = await VITDBContext.Locations.OrderBy(item => item.LocationName).AsNoTracking().ToListAsync();
                
                return locationList;
            }
         catch(Exception ex)
            {
                var locationList = await VITDBContext.Locations.OrderBy(item => item.LocationName).AsNoTracking().ToListAsync();
                return locationList;
            }
        }

        //public async Threading.Task<List<Locations>> GetAllLocationsAsync()
        //{
        //    var locationList = await VITDBContext.Locations.OrderBy(item => item.LocationName).ToListAsync();
        //    return locationList;
        //}

        //Threading.Task<List<Locations>> ILocationsRepository.GetAllLocationsAsync()
        //{
        //    var locationList =  VITDBContext.Locations.OrderBy(item => item.LocationName).ToListAsync();
        //    return locationList;
        //}


    }
}
