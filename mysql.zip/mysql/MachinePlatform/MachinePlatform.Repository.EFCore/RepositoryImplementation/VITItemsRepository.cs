﻿using Microsoft.EntityFrameworkCore;
using MachinePlatform.Repository.Interface;
using System;
using System.Collections.Generic;

using System.Linq;
using System.Text;
using MachinePlatform.Repository.EFCore;
using Threading = System.Threading.Tasks;
using MachinePlatform.Entity;
using System.Data;
using System.Data.SqlClient;
using MySql.Data.MySqlClient;

namespace MachinePlatform.Repository.EFCore.RepositoryImplementation
{
    public class VITItemsRepository : BaseRepository, IVITItemsRepository
    {
        private readonly MachinePlatformDBContext machinePlatformDBContext;

        public VITItemsRepository(MachinePlatformDBContext dBContext) : base(dBContext)
        {
            this.machinePlatformDBContext = dBContext;
        }

        public async Threading.Task<List<VITInfoSeverity>> VitInfoSeverity()
        {
            return null;
          //  return await machinePlatformDBContext.Set<VITInfoSeverity>().FromSql("spVIT_GetVitInfoSeverity").AsNoTracking().ToListAsync();
        }
        public async Threading.Task<List<VITInfoEnvName>> VitInfoEnvName()
        {
            return null;
           // return await machinePlatformDBContext.Set<VITInfoEnvName>().FromSql("spVIT_GetVitInfoEnvName").AsNoTracking().ToListAsync();
        }
        public async Threading.Task<List<VITInfoRCName>> VitInfoRCName()
        {
            return null;
            //return await machinePlatformDBContext.Set<VITInfoRCName>().FromSql("spVIT_GetVitInfoRCName").AsNoTracking().ToListAsync();
        }
        public async Threading.Task<List<VITInfoAGName>> VitInfoAGName()
        {
            return null;
            //return await machinePlatformDBContext.Set<VITInfoAGName>().FromSql("spVIT_GetVitInfoAGName").AsNoTracking().ToListAsync();
        }
        public async Threading.Task<List<WorkSheets>> WorkSheets()
        {
            return await machinePlatformDBContext.WorkSheets.OrderByDescending(u => u.YearWeek).Take(10).AsNoTracking().ToListAsync(); 
        }
        public void SaveVITItems(dynamic workSheetsInfo, DataTable saveTable)
        {
            //SqlParameter tableParameter = new SqlParameter("@Save", SqlDbType.Int);
            //string sp = string.Empty;

            //tableParameter = new SqlParameter("@SaveVITInfo", SqlDbType.Structured);
            //tableParameter.Value = saveTable;
            //tableParameter.TypeName = "dbo.VITItems";

            //sp = "sp_Save_VITInfo_API";


            //string executeSP = "EXEC " + sp + " @WSId, @UploadedOn, @WSName, @IsActive, @SaveVITInfo";
            //machinePlatformDBContext.Database.ExecuteSqlCommand(executeSP, new object[] {

            //        new SqlParameter("@WSId", workSheetsInfo.WSId),
            //        new SqlParameter("@UploadedOn", workSheetsInfo.UploadedOn),
            //        new SqlParameter("@WSName",workSheetsInfo.WSName),
            //        new SqlParameter("@IsActive",workSheetsInfo.IsActive),
            //        tableParameter });
        }



        public async Threading.Task<List<VITInfoSeverity>> VitInfoOverDueVITS()
        {
            return null;
            // return await machinePlatformDBContext.Set<VITInfoSeverity>().FromSql("spVIT_GetVitInfoSeverityRemediationDue").AsNoTracking().ToListAsync();
        }
        public async Threading.Task<List<VITInfoSeverity>> VitInfoAppNames()
        {
            // var command = new MySqlCommand("SELECT field FROM TblMachine;");
             var reader = machinePlatformDBContext.Database.ExecuteSqlCommand("SELECT * FROM TblMachine;");
          //var x= machinePlatformDBContext.
            return null;
            //return await machinePlatformDBContext.Set<VITInfoSeverity>().FromSql("spVIT_GetAppName").AsNoTracking().ToListAsync();
        }
        public async Threading.Task<List<VITInfoSeverity>> VitInfoDueByDates(DateTime effectiveDate)
        {
            return null;
            //return await machinePlatformDBContext.Set<VITInfoSeverity>().FromSql("spVIT_GetVitsDueByDate @InputDate = {0}", effectiveDate.ToString("yyyy-MM-dd")).AsNoTracking().ToListAsync();
        }
        public async Threading.Task<List<VITDetailsByAppName>> VITDetailsByAppName(string appname)
        {
            return null;
            // return await machinePlatformDBContext.Set<VITDetailsByAppName>().FromSql("spVIT_GetVitsDetailsByAppName @AppName = {0}", appname).AsNoTracking().ToListAsync();
        }
        public async Threading.Task<List<VITDetailsByAppName>> VITOpenDetailsByAppName(string appname)
        {
            return null;
          //  return await machinePlatformDBContext.Set<VITDetailsByAppName>().FromSql("spVIT_GetOpenVitsDetailsByAppName @AppName = {0}", appname).AsNoTracking().ToListAsync();
        }

        public async Threading.Task<List<VITInfoNewClosed>> VITNewClosedDetails(int fromWeek, string type, string dataReq)
        {
          
            
            return null;
           // return await machinePlatformDBContext.Set<VITInfoNewClosed>().FromSql("cpGetNOCVITInfo @FromWeek = {0},@Type={1},@DataReq={2}", fromWeek,type,dataReq).AsNoTracking().ToListAsync();
        }
    }
}
