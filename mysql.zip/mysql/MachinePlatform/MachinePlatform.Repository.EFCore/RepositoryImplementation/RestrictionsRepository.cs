﻿using Microsoft.EntityFrameworkCore;
using VITItems.Repository.Interface;
using System;
using System.Collections.Generic;

using System.Linq;
using System.Text;
using VITItems.Repository.EFCore;
using Threading = System.Threading.Tasks;
using VITItems.Entity;

namespace VITItems.Repository.EFCore.RepositoryImplementation
{
    public class RestrictionsRepository : BaseRepository, IRestrictionsRepository
    {
        private readonly VITDBContext VITDBContext;

        public RestrictionsRepository(VITDBContext dBContext) : base(dBContext)
        {
            this.VITDBContext = dBContext;
        }

        public async Threading.Task<List<RestrictionsAssignedPropertyType>> GetRestrictionsAssignedPropertyTypes()
        {
            return await VITDBContext.Set<RestrictionsAssignedPropertyType>().FromSql("EXECUTE sp_GetRestrictionsAssignedPropertyTypes_API @LocationEffectiveDate = {0}, @IsStateLocation = {1}, @LocationID = {2}", DateTime.Now.ToString("yyyy-MM-dd"), 0, 3).ToListAsync();
        }

        public async Threading.Task<List<RestrictionsAssignedPOT>> GetRestrictionsAssignedPOTs()
        {
            return await VITDBContext.Set<RestrictionsAssignedPOT>().FromSql("EXECUTE sp_GetRestrictionsAssignedPoTs_API @LocationEffectiveDate = {0}, @IsStateLocation = {1}, @LocationID = {2}", DateTime.Now.ToString("yyyy-MM-dd"), 0, 3).ToListAsync();
        }

        public async Threading.Task<List<RestrictionsAssignedPolicies>> GetRestrictionsAssignedPolicies(DateTime effectivedate, int locationID)
        {
            return await VITDBContext.Set<RestrictionsAssignedPolicies>().FromSql("EXECUTE sp_GetRestrictionsAssignedPolicies_API @LocationEffectiveDate = {0}, @LocationID = {1}", effectivedate, locationID).ToListAsync();
        }
    }
}
