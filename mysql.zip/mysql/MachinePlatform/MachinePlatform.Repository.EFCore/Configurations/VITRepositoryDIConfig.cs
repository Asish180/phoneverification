﻿
using MachinePlatform.Repository.EFCore.RepositoryImplementation;
using MachinePlatform.Repository.Interface;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using MySql.Data.MySqlClient;
using Pomelo.EntityFrameworkCore.MySql.Storage;
using System;
using System.Collections.Generic;
using System.Text;

namespace MachinePlatform.Repository.EFCore.Configurations
{
    public class MachinePlatformRepositoryDIConfig
    {
        public static void RegisterTypes(IServiceCollection serviceCollection)
        {
            var connectionString = serviceCollection.BuildServiceProvider().GetService<IConfiguration>().GetConnectionString("MachinePlatformDBConnection");
            //serviceCollection.AddDbContext<MachinePlatformDBContext>(options => setDbContextOptionValue(options, connectionString)
            //                                                , ServiceLifetime.Scoped);
            serviceCollection.AddDbContextPool<MachinePlatformDBContext>(options => options.UseMySql(connectionString));
            // serviceCollection.AddTransient<MySqlConnection>(_ => new MySqlConnection(Configuration["ConnectionStrings:Default"]));
            serviceCollection.AddScoped<IVITItemsRepository, VITItemsRepository>();
        }
        private static DbContextOptionsBuilder setDbContextOptionValue(DbContextOptionsBuilder db, string connectionstring)
        {
           // db.Use(connectionstring, sqlOtions => sqlOtions.CommandTimeout(120));
            //db.UseLazyLoadingProxies();
            /* var enviornment = Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT");

             if (enviornment == null || enviornment.ToUpper() == "LOCALDEV")
             {
                 LoggerFactory loggerFactory = new LoggerFactory();
                 loggerFactory.AddProvider(new TraceLoggerProvider());
                 db.UseLoggerFactory(loggerFactory);

             }*/

            return db;
        }

    }
}
