﻿using MachinePlatform.Entity;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Diagnostics;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Logging.Debug;
using System;
namespace MachinePlatform.Repository.EFCore
{
    public class MachinePlatformDBContext : DbContext
    {
        public static readonly LoggerFactory DBLoggerFactory
                               = new LoggerFactory(new[] { new DebugLoggerProvider((s, l) => l >= LogLevel.Information) });
        public MachinePlatformDBContext(DbContextOptions<MachinePlatformDBContext> options) : base(options)
        {

        }
        public DbSet<WorkSheets> WorkSheets { get; set; }
        public DbSet<VITInfoSeverity> VITInfoSeverities { get; set; }
        public DbSet<VITInfoEnvName> VITInfoEnvNames { get; set; }
        public DbSet<VITInfoRCName> VITInfoRCNames { get; set; }
        public DbSet<VITInfoAGName> VITInfoAGNames { get; set; }
        public DbSet<VITDetailsByAppName> VITDetailsByAppNames { get; set; }
        public DbSet<VITInfoNewClosed> VITInfoNewCloseds { get; set; }




        //protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        //{
        //    //            if (!optionsBuilder.IsConfigured)
        //    //            {
        //    //#warning To protect potentially sensitive information in your connection string, you should move it out of source code. See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.
        //    //                optionsBuilder.UseSqlServer("Server=AZUVNSQLFACC005;Database=FACC; User ID=faccmaster;Password=FAcc1234;Trusted_Connection=True;");
        //    //            }
           
        //    //optionsBuilder.ConfigureWarnings(x => x.Ignore(CoreEventId.DetachedLazyLoadingWarning));
        //}

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.HasAnnotation("ProductVersion", "2.2.6-servicing-10079");
            modelBuilder.Entity<WorkSheets>().HasKey(e => e.WSId);
            modelBuilder.Entity<VITInfoSeverity>().HasKey(o => new { o.AppName, o.Severity });
            modelBuilder.Entity<VITInfoEnvName>().HasKey(o => new { o.AppName, o.EnvName });
            modelBuilder.Entity<VITInfoRCName>().HasKey(o => new { o.AppName, o.RCName });
            modelBuilder.Entity<VITInfoAGName>().HasKey(o => new { o.AppName, o.AGName });
            modelBuilder.Entity<VITDetailsByAppName>().HasKey(o => new { o.VITNumber});
            modelBuilder.Entity<VITInfoNewClosed>().HasKey(o => new { o.AppName, o.Severity });







        }
    }
}
