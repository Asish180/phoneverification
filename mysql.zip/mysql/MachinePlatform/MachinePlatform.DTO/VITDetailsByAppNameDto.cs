﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MachinePlatform.DTO
{
   public class VITDetailsByAppNameDto
    {
        public string VITNumber { get; set; }

        public string AppName { get; set; }
        public string EnvName { get; set; }

        public string Severity { get; set; }
        public string ITCG { get; set; }
        public string RCName { get; set; }
        public string AccountableRemediationOwner { get; set; }
        public string AGName { get; set; }
        public string Substate { get; set; }

        public DateTime? Remediationduedate { get; set; }
    }
}
