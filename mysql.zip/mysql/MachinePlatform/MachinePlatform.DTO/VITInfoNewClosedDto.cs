﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MachinePlatform.DTO
{
   public class VITInfoNewClosedDto
    {
        public string AppName { get; set; }

        public string Severity { get; set; }

        public int TotalCount { get; set; }
    }
}
