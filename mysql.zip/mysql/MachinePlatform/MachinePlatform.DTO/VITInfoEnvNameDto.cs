﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MachinePlatform.DTO
{
   public class VITInfoEnvNameDto
    {

        public string AppName { get; set; }

        public string EnvName { get; set; }

        public int TotalCount { get; set; }     
        public DateTime UploadedOn { get; set; }



    }
}
