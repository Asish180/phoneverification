﻿using VITItems.Repository.EFCore;
using VITItems.Repository.EFCore.RepositoryImplementation;
using VITItems.Repository.Interface;
using System;
using System.Collections.Generic;
using System.Text;
using Threading = System.Threading.Tasks;
using Mapster;
using VITItems.DTO;

namespace VITItems.AdminService.Impl
{
    public class RestrictionsService:IRestrictions
    {
        private readonly IRestrictionsRepository restrictionsListRepository;

        public RestrictionsService(IRestrictionsRepository restrictionListRepository)
        {
            this.restrictionsListRepository = restrictionListRepository;
        }

        public async Threading.Task<List<RestrictionsAssignedPropertyTypeDto>> GetRestrictionsAssignedPropertyTypes()
        {
            var restrictionPropertyTypeList = await restrictionsListRepository.GetRestrictionsAssignedPropertyTypes();
            var restrictionPropertyDto = restrictionPropertyTypeList.Adapt<List<RestrictionsAssignedPropertyTypeDto>>();
            return restrictionPropertyDto;
        }

        public async Threading.Task<List<RestrictionsAssignedPOTDto>> GetRestrictionsAssignedPOTs()
        {
            var restrictionPOTList = await restrictionsListRepository.GetRestrictionsAssignedPOTs();
            var restrictionPOTDto = restrictionPOTList.Adapt<List<RestrictionsAssignedPOTDto>>();
            return restrictionPOTDto;
        }

        public async Threading.Task<List<RestrictionsAssignedPoliciesDto>> GetRestrictionsAssignedPolicies(DateTime effectivedate, int locationID)
        {
            var restrictionPolicyList = await restrictionsListRepository.GetRestrictionsAssignedPolicies( effectivedate,  locationID);
            var restrictionsAssignedPoliciesDto = restrictionPolicyList.Adapt<List<RestrictionsAssignedPoliciesDto>>();
            return restrictionsAssignedPoliciesDto;
        }
    }
}
