﻿using VITItems.Repository.EFCore;
using VITItems.Repository.EFCore.RepositoryImplementation;
using VITItems.Repository.Interface;
using System;
using System.Collections.Generic;
using System.Text;
using Threading = System.Threading.Tasks;
using Mapster;
using VITItems.DTO;

namespace VITItems.AdminService.Impl
{
   public class PublicClientListService : IPublicClientListService
    {
        private readonly IPublicClientListRepository PublicClientListRespository;
        public PublicClientListService(IPublicClientListRepository objPublicClientListRespository)
        {
            this.PublicClientListRespository = objPublicClientListRespository;
        }
       
        public async Threading.Task<List<PublicClientListDto>> GetPublicClientList()
        {
            var data = await PublicClientListRespository.GetPublicClientList();
            return data.Adapt<List<PublicClientListDto>>();
        }
        
    }
}
