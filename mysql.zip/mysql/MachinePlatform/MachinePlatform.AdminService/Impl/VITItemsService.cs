﻿using Mapster;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using MachinePlatform.DTO;
using MachinePlatform.Repository.Interface;
using Threading = System.Threading.Tasks;

namespace MachinePlatform.AdminService.Impl
{
    public class VITItemsService : IVITItemsService
    {
        private readonly IVITItemsRepository vitItemsRepository;

        public VITItemsService(IVITItemsRepository vitItemsRepository)
        {
            this.vitItemsRepository = vitItemsRepository;
        }

        public async Threading.Task<List<VITInfoSeverityDto>> VitInfoSeverity()
        {
            var appList = await vitItemsRepository.VitInfoSeverity();
            var appListDto = appList.Adapt<List<VITInfoSeverityDto>>();
            return appListDto;
        }
        public async Threading.Task<List<VITInfoEnvNameDto>> VitInfoEnvName()
        {
            var appList = await vitItemsRepository.VitInfoEnvName();
            var appListDto = appList.Adapt<List<VITInfoEnvNameDto>>();
            return appListDto;
        }
        public async Threading.Task<List<VITInfoRCNameDto>> VitInfoRCName()
        {
            var appList = await vitItemsRepository.VitInfoRCName();
            var appListDto = appList.Adapt<List<VITInfoRCNameDto>>();
            return appListDto;
        }
        public async Threading.Task<List<VITInfoAGNameDto>> VitInfoAGName()
        {
            var appList = await vitItemsRepository.VitInfoAGName();
            var appListDto = appList.Adapt<List<VITInfoAGNameDto>>();
            return appListDto;
        }
        public bool SaveVITItems(WorkSheetsDto workSheetsDto, DataTable saveTable)
        {
            //var restrictionRateTypeDetails = await restrictionsListRepository.SaveRestrictions(saveObject);
            vitItemsRepository.SaveVITItems(workSheetsDto, saveTable);
            return true;
        }

        public async Threading.Task<List<VITInfoSeverityDto>> VitInfoOverDueVITS()
        {
            var appList = await vitItemsRepository.VitInfoOverDueVITS();
            var appListDto = appList.Adapt<List<VITInfoSeverityDto>>();
            return appListDto;
        }
        public async Threading.Task<List<VITInfoSeverityDto>> VitInfoAppName()
        {
            var appList = await vitItemsRepository.VitInfoAppNames();
            var appListDto = appList.Adapt<List<VITInfoSeverityDto>>();
            return appListDto;
        }
        public async Threading.Task<List<WorkSheetsDto>> WorkSheets()
        {
            var appList = await vitItemsRepository.WorkSheets();
            var appListDto = appList.Adapt<List<WorkSheetsDto>>();
            return appListDto;
        }
        public async Threading.Task<List<VITInfoSeverityDto>> VitInfoDueByDates(DateTime effectiveDate)
        {
            var appList = await vitItemsRepository.VitInfoDueByDates( effectiveDate);
            var appListDto = appList.Adapt<List<VITInfoSeverityDto>>();
            return appListDto;
        }
        public async Threading.Task<List<VITDetailsByAppNameDto>> VITDetailsByAppName(string appName)
        {
            var appList = await vitItemsRepository.VITDetailsByAppName(appName);
            var appListDto = appList.Adapt<List<VITDetailsByAppNameDto>>();
            return appListDto;
        }
        public async Threading.Task<List<VITDetailsByAppNameDto>> VITOpenDetailsByAppName(string appName)
        {
            var appList = await vitItemsRepository.VITOpenDetailsByAppName(appName);
            var appListDto = appList.Adapt<List<VITDetailsByAppNameDto>>();
            return appListDto;
        }

        public async Threading.Task<List<VITInfoNewClosedDto>> VITNewClosedDetails(int fromWeek, string type, string dataReq)
        {
            var appList = await vitItemsRepository.VITNewClosedDetails(fromWeek,type,dataReq);
            var appListDto = appList.Adapt<List<VITInfoNewClosedDto>>();
            return appListDto;
        }
    }
}
