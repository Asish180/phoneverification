﻿using VITItems.Repository.EFCore;
using VITItems.Repository.EFCore.RepositoryImplementation;
using VITItems.Repository.Interface;
using System;
using System.Collections.Generic;
using System.Text;
using Threading = System.Threading.Tasks;
using Mapster;
using VITItems.DTO;

namespace VITItems.AdminService.Impl
{
   public class LocationsService:ILocations
    {
        private readonly ILocationsRepository locationsListRepository;
        public LocationsService(ILocationsRepository locationListRepository)
        {
            this.locationsListRepository = locationListRepository;
        }
       

        public async Threading.Task<List<LocationsDto>> GetAllLocationsAsync()
        {
            var locationList = await locationsListRepository.GetAllLocationsAsync();
            var locationsDto = locationList.Adapt<List<LocationsDto>>();
            return locationsDto;
        }


        public async Threading.Task<List<RestrictionsDetailsDto>> GetRestrictionsDetails()
        {
            var data = await locationsListRepository.GetRestrictionsDetails();
            return data.Adapt<List<RestrictionsDetailsDto>>();
        }
        public async Threading.Task<List<LocationTreeDto>> GetLocationTree()
        {
            var data = await locationsListRepository.GetLocationTree();
            return data.Adapt<List<LocationTreeDto>>();
        }
    }
}
