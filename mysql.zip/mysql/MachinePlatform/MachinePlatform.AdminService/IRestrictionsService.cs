﻿using VITItems.DTO;
using VITItems.Repository.EFCore;
using System;
using System.Collections.Generic;
using System.Text;
using Threading = System.Threading.Tasks;

namespace VITItems.AdminService
{
    public interface IRestrictions
    {
        Threading.Task<List<RestrictionsAssignedPropertyTypeDto>> GetRestrictionsAssignedPropertyTypes();
        Threading.Task<List<RestrictionsAssignedPOTDto>> GetRestrictionsAssignedPOTs();
        Threading.Task<List<RestrictionsAssignedPoliciesDto>> GetRestrictionsAssignedPolicies(DateTime effectivedate, int locationID);
    }
}