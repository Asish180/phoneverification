﻿using VITItems.DTO;
using VITItems.Repository.EFCore;
using System;
using System.Collections.Generic;
using System.Text;
using Threading = System.Threading.Tasks;

namespace VITItems.AdminService
{
   public interface IPublicClientListService
    {    
        Threading.Task<List<PublicClientListDto>> GetPublicClientList();
    }
}
