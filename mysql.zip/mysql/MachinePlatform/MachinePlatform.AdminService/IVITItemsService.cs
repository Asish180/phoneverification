﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using MachinePlatform.DTO;
using Threading = System.Threading.Tasks;

namespace MachinePlatform.AdminService
{
    public interface IVITItemsService
    {
        bool SaveVITItems(WorkSheetsDto workSheetsDto, DataTable saveTable);
        Threading.Task<List<VITInfoSeverityDto>> VitInfoSeverity();
        Threading.Task<List<VITInfoEnvNameDto>> VitInfoEnvName();
        Threading.Task<List<VITInfoRCNameDto>> VitInfoRCName();
        Threading.Task<List<VITInfoAGNameDto>> VitInfoAGName();

        Threading.Task<List<VITInfoSeverityDto>> VitInfoOverDueVITS();
        Threading.Task<List<VITInfoSeverityDto>> VitInfoAppName();
        Threading.Task<List<WorkSheetsDto>> WorkSheets();


        Threading.Task<List<VITInfoSeverityDto>> VitInfoDueByDates(DateTime effectiveDate);
        Threading.Task<List<VITDetailsByAppNameDto>> VITDetailsByAppName(string appName);
        Threading.Task<List<VITDetailsByAppNameDto>> VITOpenDetailsByAppName(string appName);

        Threading.Task<List<VITInfoNewClosedDto>> VITNewClosedDetails(int fromWeek, string type, string dataReq);





    }
}
