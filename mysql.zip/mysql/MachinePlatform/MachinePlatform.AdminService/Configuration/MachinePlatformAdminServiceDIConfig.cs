﻿using MachinePlatform.AdminService.Impl;
using MachinePlatform.Repository.EFCore.Configurations;
using Microsoft.Extensions.DependencyInjection;
namespace MachinePlatform.AdminService.Configuration
{
    public class MachinePlatformAdminServiceDIConfig
    {
        public static void RegisterTypes(IServiceCollection serviceCollection)
        {

            //var builder = new ConfigurationBuilder();
            //var connectionString = serviceCollection.BuildServiceProvider().GetService<IConfiguration>();
            //IConfiguration configuration = builder.Build();
            //serviceCollection.Configure<WorkspaceSettings>(configuration.GetSection("WorkspaceSettings"));
            //serviceCollection.Configure<ConnectionStrings>(configuration.GetSection("ConnectionStrings"));

            MachinePlatformRepositoryDIConfig.RegisterTypes(serviceCollection);
            serviceCollection.AddTransient<IVITItemsService, VITItemsService>();

        }

    }
}
