﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore.Internal;
using Newtonsoft.Json;
using OfficeOpenXml;
using System;
using System.Collections.Generic;
using System.Data.Entity.Core.Objects;
using System.IO;
using System.Linq;
using System.Net.Mail;
using System.Threading.Tasks;
using MachinePlatform.AdminService;
using Threading = System.Threading.Tasks;
namespace MachinePlatform.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class VITItemsManagerController : ControllerBase
    {
        public readonly IVITItemsService vitItemsService;

        public VITItemsManagerController(IVITItemsService vitService)
        {
            vitItemsService = vitService;
        }
        [HttpGet]
        public IEnumerable<string> Get()
        {
            return new string[] { "value1", "value2" };
        }
        [HttpGet]
        [Route("[action]")]
        public async Threading.Task<IActionResult> VitInfoSeverity()
        {
            try
            {
                var vitSeverity = await vitItemsService.VitInfoSeverity();


                return new JsonResult(vitSeverity, new JsonSerializerSettings { Formatting = Formatting.Indented }) { StatusCode = StatusCodes.Status200OK };
            }
            catch (Exception msg)
            {
                var msg1 = msg.Message + " stack Trace :" + msg.StackTrace + "Source :" + msg.Source;
                return new JsonResult(msg1);

            }
        }

        [HttpGet]
        [Route("[action]")]
        public async Threading.Task<IActionResult> VitInfoEnvName()
        {
            try
            {
                var vitSeverity = await vitItemsService.VitInfoEnvName();


                return new JsonResult(vitSeverity, new JsonSerializerSettings { Formatting = Formatting.Indented }) { StatusCode = StatusCodes.Status200OK };
            }
            catch (Exception msg)
            {
                var msg1 = msg.Message + " stack Trace :" + msg.StackTrace + "Source :" + msg.Source;
                return new JsonResult(msg1);

            }
        }

        [HttpGet]
        [Route("[action]")]
        public async Threading.Task<IActionResult> VitInfoRCName()
        {
            try
            {
                var vitSeverity = await vitItemsService.VitInfoRCName();


                return new JsonResult(vitSeverity, new JsonSerializerSettings { Formatting = Formatting.Indented }) { StatusCode = StatusCodes.Status200OK };
            }
            catch (Exception msg)
            {
                var msg1 = msg.Message + " stack Trace :" + msg.StackTrace + "Source :" + msg.Source;
                return new JsonResult(msg1);

            }
        }
        [HttpGet]
        [Route("[action]")]
        public async Threading.Task<IActionResult> VitInfoAGName()
        {
            try
            {
                var vitSeverity = await vitItemsService.VitInfoAGName();


                return new JsonResult(vitSeverity, new JsonSerializerSettings { Formatting = Formatting.Indented }) { StatusCode = StatusCodes.Status200OK };
            }
            catch (Exception msg)
            {
                var msg1 = msg.Message + " stack Trace :" + msg.StackTrace + "Source :" + msg.Source;
                return new JsonResult(msg1);

            }
        }
        [HttpGet]
        [Route("[action]")]
        public async Threading.Task<IActionResult> VitInfoOverDueVITS()
        {
            try
            {
                var vitSeverity = await vitItemsService.VitInfoOverDueVITS();


                return new JsonResult(vitSeverity, new JsonSerializerSettings { Formatting = Formatting.Indented }) { StatusCode = StatusCodes.Status200OK };
            }
            catch (Exception msg)
            {
                var msg1 = msg.Message + " stack Trace :" + msg.StackTrace + "Source :" + msg.Source;
                return new JsonResult(msg1);

            }
        }

        [HttpGet]
        [Route("[action]")]
        public async Threading.Task<IActionResult> VitInfoAppNames()
        {
            try
            {
                var vitSeverity = await vitItemsService.VitInfoAppName();


                return new JsonResult(vitSeverity, new JsonSerializerSettings { Formatting = Formatting.Indented }) { StatusCode = StatusCodes.Status200OK };
            }
            catch (Exception msg)
            {
                var msg1 = msg.Message + " stack Trace :" + msg.StackTrace + "Source :" + msg.Source;
                return new JsonResult(msg1);

            }
        }
    
    }
}
