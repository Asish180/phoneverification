﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace MachinePlatform.Entity
{
   public class VITInfoSeverity
    {
        public string AppName { get; set; }

        public string Severity { get; set; }

        public int TotalCount { get; set; }
        public DateTime UploadedOn { get; set; }

    }
}
