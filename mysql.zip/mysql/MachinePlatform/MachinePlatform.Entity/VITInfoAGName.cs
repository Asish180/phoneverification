﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MachinePlatform.Entity
{
   public class VITInfoAGName
    {
        public string AppName { get; set; }

        public string AGName { get; set; }

        public int TotalCount { get; set; }
        public DateTime UploadedOn { get; set; }
    }
}
