﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MachinePlatform.Entity
{
   public class WorkSheets
    {
        public int WSId { get; set; }
        public string WSName { get; set; }
        public DateTime UploadedOn { get; set; }
        public bool IsActive { get; set; }

        public string WSNameNonISOC { get; set; }

        public int YearWeek { get; set; }

    }
}
