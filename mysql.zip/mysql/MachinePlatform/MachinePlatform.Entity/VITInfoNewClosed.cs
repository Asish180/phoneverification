﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MachinePlatform.Entity
{
    public class VITInfoNewClosed
    {
        public string AppName { get; set; }

        public string Severity { get; set; }

        public int TotalCount { get; set; }
    }
}
