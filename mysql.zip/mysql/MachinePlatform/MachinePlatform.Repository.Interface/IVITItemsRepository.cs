﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using MachinePlatform.Entity;
using Threading = System.Threading.Tasks;

namespace MachinePlatform.Repository.Interface
{
    public interface IVITItemsRepository
    {
        void SaveVITItems(dynamic workSheetsInfo, DataTable saveTable);
       Threading.Task<List<VITInfoSeverity>> VitInfoSeverity();
        Threading.Task<List<VITInfoEnvName>> VitInfoEnvName();
        Threading.Task<List<VITInfoRCName>> VitInfoRCName(); 
        Threading.Task<List<VITInfoAGName>> VitInfoAGName();

        Threading.Task<List<VITInfoSeverity>> VitInfoOverDueVITS();
        Threading.Task<List<VITInfoSeverity>> VitInfoAppNames();
        Threading.Task<List<WorkSheets>> WorkSheets();


        Threading.Task<List<VITInfoSeverity>> VitInfoDueByDates(DateTime effectiveDate);
        Threading.Task<List<VITDetailsByAppName>> VITDetailsByAppName(string appName);
        Threading.Task<List<VITDetailsByAppName>> VITOpenDetailsByAppName(string appName);
        Threading.Task<List<VITInfoNewClosed>> VITNewClosedDetails(int fromWeek,string type,string dataReq);






    }
}
