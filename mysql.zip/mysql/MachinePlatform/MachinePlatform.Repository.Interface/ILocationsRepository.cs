﻿
using VITItems.Entity;
using System;
using System.Collections.Generic;
using System.Text;
using Threading = System.Threading.Tasks;
namespace VITItems.Repository.Interface
{
   public interface ILocationsRepository
    {
       Threading.Task<List<Locations>> GetAllLocationsAsync();
       // List<Locations> GetAllLocationsAsync();
        int getInt();
        Threading.Task<List<RestrictionsDetails>> GetRestrictionsDetails();
        Threading.Task<List<LocationTree>> GetLocationTree();

    }
}
