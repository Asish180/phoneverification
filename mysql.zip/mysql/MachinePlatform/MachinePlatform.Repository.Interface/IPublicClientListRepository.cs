﻿
using VITItems.Entity;
using System;
using System.Collections.Generic;
using System.Text;
using Threading = System.Threading.Tasks;
namespace VITItems.Repository.Interface
{
   public interface IPublicClientListRepository
    {
        Threading.Task<List<PublicClientListDetails>> GetPublicClientList();
    }
}