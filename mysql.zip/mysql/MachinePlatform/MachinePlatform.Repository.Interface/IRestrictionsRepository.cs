﻿using VITItems.Entity;
using System;
using System.Collections.Generic;
using System.Text;
using Threading = System.Threading.Tasks;

namespace VITItems.Repository.Interface
{
    public interface IRestrictionsRepository
    {
        Threading.Task<List<RestrictionsAssignedPropertyType>> GetRestrictionsAssignedPropertyTypes();
        Threading.Task<List<RestrictionsAssignedPOT>> GetRestrictionsAssignedPOTs();
        Threading.Task<List<RestrictionsAssignedPolicies>> GetRestrictionsAssignedPolicies(DateTime effectivedate, int locationID);

    }
}
