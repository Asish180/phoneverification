import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import * as data from '../../assets/data/contryphonecode.json';

@Component({
  selector: 'app-user-form',
  templateUrl: './user-form.component.html',
  styleUrls: ['./user-form.component.css']
})
export class UserFormComponent implements OnInit {

  title = 'Register Your Mobile Number';
  contries:Array<{id: string, text: string}>=[];
   angForm: FormGroup;
   constructor(private fb: FormBuilder) {
    this.createForm();
  }
  ngOnInit(): void {
    console.log(data.default[0]['name']);
    for (var i=0;i<data.default.length;i++)
    {
      var name=data.default[i]['name']+"("+data.default[i]['dialCode']+")";
  
      var ctry = {id:data.default[i]['isoCode'],text: name};
 
      this.contries.push(ctry);

    }
    console.log(this.contries);
  }

   createForm() {
    this.angForm = this.fb.group({
       name: ['', Validators.required ],
       address: ['', [Validators.required, Validators.email,Validators.pattern('^[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,4}$')] ],
       code:['US',Validators.required],
       phonenumber: ['',  Validators.required],
       message:['']
    });
  }

    //only number will be add
    keyPress(event: any) {
      const pattern = /[0-9\+\-\ ]/;
      let inputChar = String.fromCharCode(event.charCode);
      if (event.keyCode != 8 && !pattern.test(inputChar)) {
        event.preventDefault();
      }
    }

    submitForm()
    {
      alert("hi");
    }
    onScriptLoad() {
      console.log('Google reCAPTCHA loaded and is ready for use!')
  }

  onScriptError() {
      console.log('Something went long when loading the Google reCAPTCHA')
  }


  
}
