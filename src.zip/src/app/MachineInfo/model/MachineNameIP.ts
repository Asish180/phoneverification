export class MachineNameIP
{
    id:number;
    machineIp: string;
    machineName: string; 
    userName:string;
    emailId:string;
    phoneNo:string; 
    createdDate:string;

}