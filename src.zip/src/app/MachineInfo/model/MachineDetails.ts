export class MachineDetails
{
    Id: number;
    IpAddress: string;
    MachineId: string;
    userName:string;
    emailId:string;
    phoneNo:string;
    CreatedDate: Date;

}