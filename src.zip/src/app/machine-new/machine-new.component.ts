import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MachineNameIP } from '../MachineInfo/model/MachineNameIP';
import { MachineDetails } from '../MachineInfo/model/MachineDetails';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { AppEndPoint, AppEndPointName } from '../shared/core/app.endpoint';
import { MatSnackBar } from '@angular/material/snack-bar';
import * as moment from 'moment';

@Component({
  selector: 'app-machine-new',
  templateUrl: './machine-new.component.html',
  styleUrls: ['./machine-new.component.css']
})
export class MachineNewComponent  {
  public machineName="";
  public machineip=""; 
  public userName="";
  public emailId="";
  public phoneNo="";
  public id:number;
  private action="";
  public createdDate:any;
  message: string = "Are you sure?"
  confirmButtonText = "Yes"
  cancelButtonText = "Cancel"
  private machineDetails:MachineDetails[]; 
  private apiURL;
  public title;
  constructor(private http:HttpClient,private _snackBar: MatSnackBar,
    @Inject(MAT_DIALOG_DATA) private data: any,
    private dialogRef: MatDialogRef<MachineNewComponent>) {
 
      if(this.data.id>0)
      {
        console.log(this.data);
        this.machineip=this.data.machineIp;
        this.machineName=this.data.machineName;
        this.userName=this.data.userName;
        this.emailId=this.data.emailId;
        this.phoneNo=this.data.phoneNo;
        this.createdDate=this.data.createdDate;
        this.title="Edit Record :" ;  
        this.id= this.data.id;
        this.action="edit"
      }
      else{
        this.action="add";
        this.title="Add New";
      }


  }

  onConfirmClick(): void {

    if(this.machineip.length<=0)
    {
      alert("please enter machine Ip");
      return;
    }
    if(this.machineName.length<=0)
    {
      alert("please enter machine Name");
      return;
    }
    if(this.action=="edit")
    {
    this.updateMachine()
    }
    else{
      this.addNewMachine();

    }
  }
  addNewMachine():void{

    this.apiURL=AppEndPoint.find(n=>n.EndPointName==AppEndPointName.AddMachine).EndpointUrl;
    var newMachine= new MachineNameIP();
    newMachine.id=0;
    newMachine.machineIp=this.machineip;
    newMachine.machineName=this.machineName;
    newMachine.userName=this.userName;
    newMachine.emailId=this.emailId;
    newMachine.phoneNo=this.phoneNo;
    if(this.createdDate!=null)
    newMachine.createdDate=this.createdDate.toDateString();
    else
    newMachine.createdDate=new Date().toDateString();
    const FormDataJson= JSON.stringify(newMachine);
    const ParseHeaders={
      headers:new HttpHeaders(
        {
          'Content-Type':'application/json'
        }
      )
    }
    this.http.post<MachineNameIP>(this.apiURL,FormDataJson,ParseHeaders).toPromise().then(
      data=>{
        console.log(data);
        this._snackBar.open("Record Added Successfully", "", {
          duration: 5000,
        });; 
    this.dialogRef.close(true);
       
      },Error=>{
    this.dialogRef.close(true);

        alert("Failed to Save Data");
      }
    )
  }

  updateMachine():void{

    this.apiURL=AppEndPoint.find(n=>n.EndPointName==AppEndPointName.UpdateMachine).EndpointUrl;
    var newMachine= new MachineNameIP();
    newMachine.id=+this.id;
    newMachine.machineIp=this.machineip;
    newMachine.machineName=this.machineName;
    newMachine.userName=this.userName;
    newMachine.emailId=this.emailId;
    newMachine.phoneNo=this.phoneNo;
    newMachine.createdDate=moment(this.createdDate).format('yyyy-MM-DD');;
    const FormDataJson= JSON.stringify(newMachine);
    console.log(newMachine);
    const ParseHeaders={
      headers:new HttpHeaders(
        {
          'Content-Type':'application/json'
        }
      )
    }
    this.http.post<MachineNameIP>(this.apiURL,FormDataJson,ParseHeaders).toPromise().then(
      data=>{
        console.log(data);
        this._snackBar.open("Record Updated Successfully", "", {
          duration: 5000,
        }); 
    this.dialogRef.close(true);
       
      },Error=>{
    this.dialogRef.close(true);

        alert("Failed to Save Data");
      }
    )
  }
  openSnackBar(message: string, action: string) {
    this._snackBar.open(message, action, {
      duration: 5000,
    });
  }
}
