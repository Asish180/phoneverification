export class AppEndPointDto
{
    EndPointName:string;
    EndpointUrl:string;
}