import {environment} from '../../../environments/environment';
import {AppEndPointDto} from '../models/app.endpoint-dto'

export enum AppEndPointName{
    MachineList="MachineList",
    AddMachine="AddNewMachine",
    UpdateMachine="UpdateMachine",
    RemoveMachine="RemoveMachine",
}

export const AppEndPoint:AppEndPointDto[]=[
    {
        EndPointName:AppEndPointName.MachineList,
        EndpointUrl:environment.Machine.apiURL+'/MachineInfoManager/MachineList'
    },
    {
        EndPointName:AppEndPointName.AddMachine,
        EndpointUrl:environment.Machine.apiURL+'/MachineInfoManager/AddNewMachine'
    },
    {
        EndPointName:AppEndPointName.UpdateMachine,
        EndpointUrl:environment.Machine.apiURL+'/MachineInfoManager/UpdateMachine '
    },
    {
        EndPointName:AppEndPointName.RemoveMachine,
        EndpointUrl:environment.Machine.apiURL+'/MachineInfoManager/RemoveMachine '
    },
]