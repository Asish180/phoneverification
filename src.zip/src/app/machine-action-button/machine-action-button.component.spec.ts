import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MachineActionButtonComponent } from './machine-action-button.component';

describe('MachineActionButtonComponent', () => {
  let component: MachineActionButtonComponent;
  let fixture: ComponentFixture<MachineActionButtonComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MachineActionButtonComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MachineActionButtonComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
