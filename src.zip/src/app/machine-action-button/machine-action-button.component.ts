import { Component, OnInit } from '@angular/core';
import{ MatDialog,MatDialogConfig} from "@angular/material/dialog";
import { MachineNameIP } from '../MachineInfo/model/MachineNameIP';
import { MachineNewComponent } from '../machine-new/machine-new.component';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { AppEndPoint, AppEndPointName } from '../shared/core/app.endpoint';
@Component({
  selector: 'app-machine-action-button',
  templateUrl: './machine-action-button.component.html',
  styleUrls: ['./machine-action-button.component.css']
})
export class MachineActionButtonComponent implements OnInit {

  public machineNameIPEdit= new MachineNameIP();
  private apiURL;
  constructor(private dialog:MatDialog,private http:HttpClient,) { }

  ngOnInit(): void {
  }
  private params:any;
  agInit(params:any):void{
    this.params=params;
  }
onEdit()
{
  console.log(this.params.node.data["Id"]);
  this.machineNameIPEdit.id=this.params.node.data["Id"];
  this.machineNameIPEdit.machineIp=this.params.node.data["IpAddress"];
  this.machineNameIPEdit.machineName=this.params.node.data["MachineId"];
  this.machineNameIPEdit.userName=this.params.node.data["userName"];
  this.machineNameIPEdit.emailId=this.params.node.data["emailId"];
  this.machineNameIPEdit.phoneNo=this.params.node.data["phoneNo"];


this.openDialog();

}
onDelete()
{
  var machId=this.params.node.data["Id"];
  console.log(this.params.node.data["Id"]);
  if(confirm("are you sure?"))
  {
    console.log("sure");
    this.RemoveMachine();
  }
  else{
    console.log("not sure");
  }
  
}
RemoveMachine()
{
  this.apiURL=AppEndPoint.find(n=>n.EndPointName==AppEndPointName.RemoveMachine).EndpointUrl;
    var newMachine= new MachineNameIP();
    newMachine.id=+this.params.node.data["Id"];;
    newMachine.machineIp=this.params.node.data["IpAddress"];
    newMachine.machineName=this.params.node.data["MachineId"];
    newMachine.userName=this.params.node.data["userName"];
    newMachine.emailId=this.params.node.data["emailId"];
    newMachine.phoneNo=this.params.node.data["phoneNo"];
    const FormDataJson= JSON.stringify(newMachine);
    console.log(newMachine);
    const ParseHeaders={
      headers:new HttpHeaders(
        {
          'Content-Type':'application/json'
        }
      )
    }
    this.http.post<MachineNameIP>(this.apiURL,FormDataJson,ParseHeaders).toPromise().then(
      data=>{
        console.log(data);
        alert(data); 
   
       
      },Error=>{
   

        alert("Failed to Save Data");
      }
    )
}
openDialog() {
  var d=new MachineNameIP();
  d.id=0;
  d.machineName="test";
  d.machineIp="testIp";
  console.log(this.machineNameIPEdit);
   const dialogRef = this.dialog.open(MachineNewComponent,{
     disableClose: true ,
     width:'40%',
     data:this.machineNameIPEdit
   });
  
}
}
