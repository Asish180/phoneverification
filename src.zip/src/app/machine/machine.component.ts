import { Component, OnInit } from '@angular/core';
import {HttpClient, HttpHeaders} from '@angular/common/http';
import { MachineDetails } from '../MachineInfo/model/MachineDetails';
import { AppEndPoint, AppEndPointName } from '../shared/core/app.endpoint';
import { MachineActionButtonComponent } from '../machine-action-button/machine-action-button.component';
import { MachineNameIP } from '../MachineInfo/model/MachineNameIP';
import {MatDialog,MatDialogConfig} from '@angular/material/dialog'
import { MachineNewComponent } from '../machine-new/machine-new.component';
import { MatSnackBar } from '@angular/material/snack-bar';
import * as moment from 'moment';
@Component({
  selector: 'app-machine',
  templateUrl: './machine.component.html',
  styleUrls: ['./machine.component.css']
})
export class MachineComponent implements OnInit {
 public columnDefs;
 public machineDetails:MachineDetails[]; 
private apiURL;
public machineName="";
public machineip="";
public machineNameIPEdit= new MachineNameIP();
rowData : any;
rowHeight:any=40;
frameworkComponents: any;
  constructor( private http:HttpClient,private dialog:MatDialog,private _snackBar: MatSnackBar) {
    this.frameworkComponents = {
      buttonRenderer: MachineActionButtonComponent,
    }
    this.apiURL=AppEndPoint.find(n=>n.EndPointName===AppEndPointName.MachineList).EndpointUrl;
    this.http.get<MachineDetails[]>(this.apiURL).toPromise().then(result=>
    {
      this.machineDetails=result;
      this.rowData=result;
      console.log(this.machineDetails);
    },Error=>{alert("failed to load data")})

    this.columnDefs = [
      {headerName: 'ID', field: 'Id',sortable:true,filter:"agTextColumnFilter",},
      {headerName: 'Ip Address', field: 'IpAddress',sortable:true,filter:"agTextColumnFilter", },
      {headerName: 'Machine Name', field: 'MachineId',sortable:true,filter:"agTextColumnFilter",},
      {headerName: 'User Name', field: 'userName',sortable:true,filter:"agTextColumnFilter",},
      {headerName: 'Email Id', field: 'emailId',sortable:true,filter:"agTextColumnFilter",},
      {headerName: 'Ph Number', field: 'phoneNo',sortable:true,filter:"agTextColumnFilter",},

      {headerName: 'Created Date', field: 'CreatedDate',sortable:true,filter:"agDateColumnFilter",
      valueFormatter: function (params) {
        return moment(params.value).format('yyyy-MM-DD');
    },
    },
    //   {headerName:'Actions', 
    //   //cellRenderer: 'buttonRenderer',
    //   cellRendererFramework: MachineActionButtonComponent,

    //   onClick: this.onRowPublishBtnClick.bind(this), 
    //   pinned:'right',
    //   width:120
     
    // }
    {  
      headerName: "Actions",  
      pinned:'right',
      width:180,
      template:  
      ` <button style="width:50px;"  class=" mat-raised-button btn-primary "  data-action-type="edit" >
      edit
    </button>
    <button style="width:50"  class=" mat-raised-button btn-danger " data-action-type="delete" aria-label="Example icon button with a heart icon">
    delete
    </button>`  
      } 
  ];
  
   }

  ngOnInit(): void {
    this.apiURL=AppEndPoint.find(n=>n.EndPointName===AppEndPointName.MachineList).EndpointUrl;
    console.log(this.apiURL);
    this.http.get<MachineDetails[]>(this.apiURL).toPromise().then(result=>
      {
        this.machineDetails=result;
        this.rowData=result;
        console.log(this.machineDetails);
      },Error=>{alert("failed to load data")})
  }

  addNew()
  {
const dialogConfig= new MatDialogConfig();
dialogConfig.disableClose=true;
dialogConfig.autoFocus=true;
dialogConfig.height="50%";
dialogConfig.width="50%";
this.dialog.open(MachineNewComponent,dialogConfig);
  }

  openDialog() {
   var d=new MachineNameIP();
   d.id=0;
   d.machineName="test";
   d.machineIp="testIp";
    const dialogRef = this.dialog.open(MachineNewComponent,{
      disableClose: true ,
      width:'40%',
      data:d
    });
   

    dialogRef.afterClosed().subscribe(result => {
      this.apiURL=AppEndPoint.find(n=>n.EndPointName===AppEndPointName.MachineList).EndpointUrl;
      console.log(this.apiURL);
      this.http.get<MachineDetails[]>(this.apiURL).toPromise().then(result=>
        {
          this.machineDetails=result;
          this.rowData=result;
          console.log(this.machineDetails);
        },Error=>{alert("failed to load data")})
      console.log('The dialog was closed');
      console.log('result');

     
    });
  }
  refresh()
  {
    this.apiURL=AppEndPoint.find(n=>n.EndPointName===AppEndPointName.MachineList).EndpointUrl;
    console.log(this.apiURL);
    this.http.get<MachineDetails[]>(this.apiURL).toPromise().then(result=>
      {
        this.machineDetails=result;
        this.rowData=result;
        console.log(this.machineDetails);
        this.openSnackBar("Grid refreshed","hurray");
      },Error=>{alert("failed to load data")})
  }
  addNewMachine():void{

    this.apiURL=AppEndPoint.find(n=>n.EndPointName==AppEndPointName.AddMachine).EndpointUrl;
    var newMachine= new MachineNameIP();
    newMachine.id=0;
    newMachine.machineIp=this.machineip;
    newMachine.machineName=this.machineName;
    const FormDataJson= JSON.stringify(newMachine);
    const ParseHeaders={
      headers:new HttpHeaders(
        {
          'Content-Type':'application/json'
        }
      )
    }
    this.http.post<MachineNameIP>(this.apiURL,FormDataJson,ParseHeaders).toPromise().then(
      data=>{
        console.log(data);
        alert(data); 
        this.apiURL=AppEndPoint.find(n=>n.EndPointName===AppEndPointName.MachineList).EndpointUrl;
    
    this.http.get<MachineDetails[]>(this.apiURL).toPromise().then(result=>
      {
        this.machineDetails=result;
        this.rowData=result;
        console.log(this.machineDetails);
      },Error=>{alert("failed to load data")})
      },Error=>{
        alert("Failed to Save Data");
      }
    )
  }
  openSnackBar(message: string, action: string) {
    this._snackBar.open(message, action, {
      duration: 5000,
    });
  }
  onGridRowClicked(e: any) {  
    if (e.event.target !== undefined) {  
    let actionType = e.event.target.getAttribute("data-action-type");  
    console.log(e);
    switch (actionType) {  
    case "edit":  
    {  
      console.log(e.data["Id"])
      this.onEdit(e.data);
    console.log("Edit action clicked");  
    break;
    }  
    case "delete":  
    {  
    this.onDelete(e.data);
    console.log("Delete action clicked");  
    break;
    }  
    }  
    }  
  }
  onEdit(params:any)
  {
    console.log(params["Id"]);
    this.machineNameIPEdit.id=params["Id"];
    this.machineNameIPEdit.machineIp=params["IpAddress"];
    this.machineNameIPEdit.machineName=params["MachineId"];
    this.machineNameIPEdit.userName=params["userName"];
    this.machineNameIPEdit.emailId=params["emailId"];
    this.machineNameIPEdit.phoneNo=params["phoneNo"];
    this.machineNameIPEdit.createdDate=params["CreatedDate"];
  
  
  this.openEditDialog();

  }
  openEditDialog() {
    var d=new MachineNameIP();
    d.id=0;
    d.machineName="test";
    d.machineIp="testIp";
    console.log(this.machineNameIPEdit);
     const dialogRef = this.dialog.open(MachineNewComponent,{
       disableClose: true ,
       width:'40%',
       data:this.machineNameIPEdit
     });

     dialogRef.afterClosed().subscribe(result => {
      this.apiURL=AppEndPoint.find(n=>n.EndPointName===AppEndPointName.MachineList).EndpointUrl;
      console.log(this.apiURL);
      this.http.get<MachineDetails[]>(this.apiURL).toPromise().then(result=>
        {
          this.machineDetails=result;
          this.rowData=result;
          console.log(this.machineDetails);
        },Error=>{ this._snackBar.open("Failed to Refresh grid", "", {
          duration: 5000,
        });})
      console.log('The dialog was closed');
      console.log('result');

     
    });
  }
  

  onDelete(params:any)
{
  var machId=params["Id"];
  console.log(params["Id"]);
  if(confirm("are you sure?"))
  {
    console.log("sure");
    this.RemoveMachine(params);
  }
  else{
    console.log("not sure");
  }
  
}
RemoveMachine(params:any)
{
  this.apiURL=AppEndPoint.find(n=>n.EndPointName==AppEndPointName.RemoveMachine).EndpointUrl;
    var newMachine= new MachineNameIP();
    newMachine.id=+params["Id"];;
    newMachine.machineIp=params["IpAddress"];
    newMachine.machineName=params["MachineId"];
    newMachine.userName=params["userName"];
    newMachine.emailId=params["emailId"];
    newMachine.phoneNo=params["phoneNo"];
    const FormDataJson= JSON.stringify(newMachine);
    console.log(newMachine);
    const ParseHeaders={
      headers:new HttpHeaders(
        {
          'Content-Type':'application/json'
        }
      )
    }
    this.http.post<MachineNameIP>(this.apiURL,FormDataJson,ParseHeaders).toPromise().then(
      data=>{
        console.log(data);
        this._snackBar.open("Record Removed Successfully", "", {
          duration: 5000,
        });
        this.apiURL=AppEndPoint.find(n=>n.EndPointName===AppEndPointName.MachineList).EndpointUrl;
    
        this.http.get<MachineDetails[]>(this.apiURL).toPromise().then(result=>
          {
            this.machineDetails=result;
            this.rowData=result;
            console.log(this.machineDetails);
          },Error=>{ this._snackBar.open("Failed to load the Record", "", {
            duration: 5000,
          });})
       
      },Error=>{
   

        alert("Failed to Remove Record");
      }
    )
}
 
}
