import { INavData } from '@coreui/angular';

export const navItems: INavData[] = [
  {
    name: 'Dashboard',
    url: '/Machine',
    icon: 'icon-speedometer',
 
  },
  {
    name: 'User',
    url: '/User',
    icon: 'icon-user',
 
  },
];
