export const environment = {
  production: true,
  Machine:{
    apiURL:'http://machineinfo.azurewebsites.net/api',
    maxFileSize:'73400320'
  }
};
